# Horizontal snapping sections (advanced) - ScrollTrigger + Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/maxime-potier/pen/qBYYKBK](https://codepen.io/maxime-potier/pen/qBYYKBK).

Horizontal snapping sections